# figure 04 - Map of Moomin character walks after drinking Salmiakki



source("./config.R")



### parameters ##



# --- file output ---

write.pdf = T



# --- limits and margins ---

margins = c(2, 2, 2, 0)

xlim = c(-100, 100)

ylim = c(-100, 100)

# --- title and axes ---

title.label = "Moomin path in Naantali after drinking Salmiakki"



### data ###



# read the arguments

file_names = commandArgs(trailingOnly = T)

n.files = length(file_names)

# load the data

data = list()

for (i in 1:n.files) {
  
  data[[i]] = read.table(file_names[i], header = T, sep = "\t")
  
}



### plot ###



#--- file output ---

if (write.pdf) {
  pdf(file = "./output/figure04.pdf",
      width = 6, height = 6, pointsize = 12)
}



#--- empty plot ---

par(mar = margins) # set the outer margins

plot(0, 0, type = "n", xlim = xlim, ylim = ylim, 
     xlab = "", ylab = "", axes = F, bty = "n",
     asp = 1) # asp = 1 determine the aspect ratio



#--- draw the points ---

for (i in 1:length(data)) {

lines(data[[i]]$x, data[[i]]$y, col = i)

}

points(0, 0, pch = 21, col = "black", bg = "green") # start



#--- axes and title ---

axis(1)

axis(2)

title(title.label)

mtext("x", 1, line = 2)

mtext("y", 2, line = 3)



#--- close the file ---

if (write.pdf) {
  dev.off()
}

