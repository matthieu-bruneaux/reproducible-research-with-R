### Global settings ###



#--- depth color gradient ---

cfg.depth.col.shallow = "salmon"

cfg.depth.col.deep = "navyblue"
