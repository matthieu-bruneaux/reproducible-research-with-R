# figure 01 - Map of earthquakes off Fiji
# using R dataset 'quakes'



source("./config.R")



### parameters ###



# --- file output ---

write.pdf = F # default

arguments = commandArgs(trailingOnly = T)

if (length(arguments) > 0 && arguments == "pdf") {
  
  write.pdf = T
  
}

# --- limits and margins ---

margins = c(3, 4, 2, 0)

xlim = c(165, 190)

ylim = c(-40, -10)

# --- title and axes ---

title.label = "Locations of earthquakes off Fiji"

x.values.at = seq(165, 190, by = 5)

y.values.at = seq(-40, -10, by = 10)

xlab = "Longitude"

ylab = "Latitude"

#--- colors ---

depth.ncol = 100

depth.col.shallow = cfg.depth.col.shallow

depth.col.deep = cfg.depth.col.deep



### data ###



long = quakes$long

lat = quakes$lat

depth = quakes$depth



### plot ###



#--- file output ---

if (write.pdf) {
pdf(file = "./output/figure01.pdf",
    width = 6, height = 4, pointsize = 12)
}



#--- empty plot ---

par(mar = margins) # set the outer margins

plot(0, 0, type = "n", xlim = xlim, ylim = ylim, 
     xlab = "", ylab = "", axes = F, bty = "n",
     asp = 1) # asp = 1 determine the aspect ratio



#--- prepare the color palette for depth ---

color.gradient = colorRampPalette(c(depth.col.shallow, depth.col.deep))

depth.colors = color.gradient(depth.ncol)



#--- draw the points ---

points(long, lat, col = depth.colors[cut(depth, depth.ncol)], pch = 16, cex = 0.5)



#--- axes and title ---

axis(1, at = x.values.at)

axis(2, at = y.values.at, las = 1)

title(title.label)

mtext(xlab, 1, line = 2)

mtext(ylab, 2, line = 3)


#--- close the file ---

if (write.pdf) {
dev.off()
}