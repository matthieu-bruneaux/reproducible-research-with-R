# figure 03 - Map of earthquakes off Fiji
# using R dataset 'quakes'



library(ggplot2)



### parameters ###



# --- file output ---

write.pdf = F # default

arguments = commandArgs(trailingOnly = T)

if (length(arguments) > 0 && arguments == "pdf") {

write.pdf = T

}



### load data ###



paintball = read.table("../data/paintball_data", header = T, 
                       sep ="\t")



### plot ###



#--- file output ---
if (write.pdf) {
  pdf(file = "./output/figure03.pdf",
      width = 6, height = 4, pointsize = 12)
}



#--- ggplot ---

paintball_plot = ggplot(paintball, aes(x = time.min, y = balls.used, col = user)) +
  geom_line()

print(paintball_plot)



#--- close the file ---

if (write.pdf) {
  dev.off()
}

