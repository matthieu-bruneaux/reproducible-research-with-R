# generate a random walk

random_walk = function(n.steps = 10000, step.length = 1) {
  
  # TAKES
  # the number of steps and their length
  #
  # RETURNS
  # a data frame with the position x and y
  
  x = 0
  
  y = 0
  
  for (i in 1:(n.steps - 1)) {
    
    angle = sample(1:360, 1) / 360 * 2 * pi
    
    x[i + 1] = x[i] + step.length * cos(angle)
    
    y[i + 1] = y[i] + step.length * sin(angle)
    
  }
  
  data.frame(x, y)
  
}

a = random_walk()

file_name = "random_walk_05.dat"

write.table(a, file_name, sep = "\t", col.names = T, row.names = F, quote = F)